import React from 'react'

import './PaymentPage.css'

const PaymentPage = () => {
  return (
    <div className='paymentContainer'>
      <img src='/assets/images/pay.jpeg'/>
    </div>
  )
}

export default PaymentPage