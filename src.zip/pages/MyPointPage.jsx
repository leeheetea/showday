import React from 'react'
import MyPagePoint from '../components/MyPagePoint'

const MyPointPage = () => {
  return (
    <div>
      <MyPagePoint></MyPagePoint>
    </div>
  )
}

export default MyPointPage