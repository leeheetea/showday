//const userData = [
 // {id: 1, name: '홍길동', email : 'aaa@test.com', number: '010-1234-5678'},
 // {id: 2, name: '홍길자', email : 'bbb@test.com', number: '010-1111-2222'}
//];
export const BOOKDATA = [
  {bId: 1, title: `[기획공연] 뮤지컬 '사랑은 아름다워'-광주`}
];

// export const mySeats = [
//   {sId: 1, sname: '1열 15번'}
// ];

// const allSeats = [

// ];

export default BOOKDATA